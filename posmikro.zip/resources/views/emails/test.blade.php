<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>

<div>
<p>hello... </p>
<p>selamat bergabung di {{ $name }}</p>
</div>
</body>
</html>