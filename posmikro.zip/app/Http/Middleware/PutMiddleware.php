<?php

namespace App\Http\Middleware;

use Closure;

class PutMiddleware
{
    public function handle($request, Closure $next)
    {
        if(!$request->isMethod("put")) {
            $response['error'][] = [
                    'status'            => false,
                    'message'           => 'Method not allowed',
                    'methode_allowed'   => "Put",
                    'code'              => 400
                ];
            return response()->json($response, 400);
        }
        return $next($request);
    }

}
