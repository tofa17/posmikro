<?php

namespace App\Http\Middleware;

use Closure;

class DeleteMiddleware
{
    public function handle($request, Closure $next)
    {
        if(!$request->isMethod("delete")) {
            $response['error'][] = [
                    'status'            => false,
                    'message'           => 'Method not allowed',
                    'methode_allowed'   => "Delete",
                    'code'              => 400
                ];
            return response()->json($response, 400);
        }
        return $next($request);
    }

}
