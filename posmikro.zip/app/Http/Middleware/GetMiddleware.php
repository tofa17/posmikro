<?php

namespace App\Http\Middleware;

use Closure;

class GetMiddleware
{
    public function handle($request, Closure $next)
    {
        if(!$request->isMethod("get")) {
            $response['error'][] = [
                    'status'            => false,
                    'message'           => 'Method not allowed',
                    'methode_allowed'   => "Get",
                    'code'              => 400
                ];
            return response()->json($response, 400);
        }
        return $next($request);
    }

}
