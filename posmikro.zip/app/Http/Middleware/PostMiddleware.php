<?php

namespace App\Http\Middleware;

use Closure;

class PostMiddleware
{
    public function handle($request, Closure $next)
    {
        if(!$request->isMethod("post")) {
            $response['error'][] = [
                    'status'            => false,
                    'message'           => 'Method not allowed',
                    'methode_allowed'   => "Post",
                    'code'              => 400
                ];
            return response()->json($response, 400);
        }
        return $next($request);
    }
}
