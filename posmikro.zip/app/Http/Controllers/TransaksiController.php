<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Validator;
use DB;

class TransaksiController extends Controller
{
    function __construct(){
        $this->middleware('AuthKeyMiddleware');
    }
    public function index(){
        return $this->httpBadRequest('Unknown method');
    }
    public function addTransaksi(Request $request){
        $validator = Validator::make($request->all(),
            [
                'produk_id'         => 'required|integer',
                'kode_transaksi'    => 'required',
                'tot_item'          => 'required|integer',
                'tot_harga'         => 'required|integer',
                'tgl_order'         => 'required'
            ]);
        if ($validator->fails()) {
            $message = $validator->errors();
            return $this->httpUnprocessableEntity($message);
        }
        $id_outlet = DB::table($this->keyID($request).'_kasirs')
                        ->where('id', $this->userID($request))
                        ->value('outlet_id');
        $data = DB::table($this->keyID($request).'_transaksis')
                    ->insert
                    ([
                        'outlet_id'         => $id_outlet,
                        'produk_id'         => $request->input('produk_id'),
                        'kode_transaksi'    => $request->input('kode_transaksi'),
                        'tot_item'          => $request->input('tot_item'),
                        'tot_harga'         => $request->input('tot_harga'),
                        'tgl_order'         => $request->input('tgl_order')
                    ]);
        if ($data) {
            return $this->httpCreate();
        }
    }
    
}
