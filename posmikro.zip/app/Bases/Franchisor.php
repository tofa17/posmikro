<?php

namespace App\Bases;

use Illuminate\Database\Eloquent\Model;

class Franchisor extends Model
{
	protected $table = 'franchisors';
}
