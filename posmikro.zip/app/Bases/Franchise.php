<?php

namespace App\Bases;

use Illuminate\Database\Eloquent\Model;

class Franchise extends Model
{
    protected $table = 'franchises';
    protected $primaryKey = 'id';
}
